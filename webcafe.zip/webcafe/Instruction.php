<?php

/* ქვემოთ მოცემული კოდი ჩასვით თემის functions.php -ში თქვენთვის სასურველ ადგილას */
/* გთხოვთ არ შეცვალოთ საავტორო უფლებებში ჩაწერილი კომენტარები */

// author: Nika dangadze
// FB: https://www.facebook.com/nickolas.danga.3
// Gmail: Nicolas.danga1997@gmail.com
// Tel : 595519091
      
 function webcafe()
 {
     locate_template( array( '/webcafe/webcafe.php' ), true, true );
}
add_action( 'after_setup_theme', 'webcafe' );
// კეთილი სურვილებით .